<?php

/*
   Plugin Name: Paktolus Interview Task
   Plugin URI: https://www.linkedin.com/company/paktolus-solutions-llc/
   description: I have created this plugin for interview process. 
   Version: 1.0
   Author: Sivashankar R
   Author URI: https://www.linkedin.com/in/siva-shankar-r/
   License: GPL2
   */
ob_start();

if (!defined('ABSPATH')) {
    define('ABSPATH', dirname(__FILE__) . '/');
}

include_once("create-table.php");


register_activation_hook(__FILE__, 'install_task_plugin');


register_deactivation_hook(__FILE__, 'my_plugin_remove_database');

add_action('admin_menu', 'add_menu_page_function_task');
function add_menu_page_function_task()
{
    add_menu_page('Paktolus Task', 'Paktolus Task', 'manage_options', 'paktolus-task', 'task_creator', 'dashicons-buddicons-tracking');
} 
function task_creator()
{
    global $wpdb;

    $DBP_tb_name = $wpdb->prefix . "customerinfo";
    $query = "SELECT * FROM $DBP_tb_name";
    $postlist = $wpdb->get_results($query);

?>
    <table>
        <tr>
            <th style="border: 1px solid #cccc; padding: 10px;">Sno</th>
            <th style="border: 1px solid #cccc; padding: 10px;">First Name</th>
            <th style="border: 1px solid #cccc; padding: 10px;">Last Name</th>
            <th style="border: 1px solid #cccc; padding: 10px;">Phone Number</th>
            <th style="border: 1px solid #cccc; padding: 10px;">Email Id</th>
            <th style="border: 1px solid #cccc; padding: 10px;">House Number / Street Name</th>
            <th style="border: 1px solid #cccc; padding: 10px;">Appartment</th>
            <th style="border: 1px solid #cccc; padding: 10px;">City</th>
            <th style="border: 1px solid #cccc; padding: 10px;">Pin Code</th>
            <th style="border: 1px solid #cccc; padding: 10px;">Amount</th>
            <th style="border: 1px solid #cccc; padding: 10px;">Order ID</th>
            <th style="border: 1px solid #cccc; padding: 10px;">Payment ID</th>
            <th style="border: 1px solid #cccc; padding: 10px;">Payment Status</th>
            <th style="border: 1px solid #cccc; padding: 10px;">Paied Date</th>
        </tr>
        <?php
        $i = 1;
        foreach ($postlist as $customer_info) {
        ?>
            <tr>
                <td style="border: 1px solid #cccc; padding: 10px;"><?php echo $i; ?></td>
                <td style="border: 1px solid #cccc; padding: 10px;"><?php echo $customer_info->first_name; ?></td>
                <td style="border: 1px solid #cccc; padding: 10px;"><?php echo $customer_info->last_name; ?></td>
                <td style="border: 1px solid #cccc; padding: 10px;"><?php echo $customer_info->phone; ?></td>
                <td style="border: 1px solid #cccc; padding: 10px;"><?php echo $customer_info->email; ?></td>
                <td style="border: 1px solid #cccc; padding: 10px;"><?php echo $customer_info->house_no_name; ?></td>
                <td style="border: 1px solid #cccc; padding: 10px;"><?php echo $customer_info->appartment; ?></td>
                <td style="border: 1px solid #cccc; padding: 10px;"><?php echo $customer_info->city; ?></td>
                <td style="border: 1px solid #cccc; padding: 10px;"><?php echo $customer_info->pin_code; ?></td>
                <td style="border: 1px solid #cccc; padding: 10px;"><?php echo $customer_info->amount; ?></td>
                <td style="border: 1px solid #cccc; padding: 10px;"><?php echo $customer_info->order_id; ?></td>
                <td style="border: 1px solid #cccc; padding: 10px;"><?php echo $customer_info->payment_id; ?></td>
                <td style="border: 1px solid #cccc; padding: 10px;"><?php echo $customer_info->paystatus; ?></td>
                <td style="border: 1px solid #cccc; padding: 10px;"><?php echo $customer_info->inserteddate; ?></td>
            </tr>
        <?php
            $i++;
        }

        ?>
    </table>
<?php

}
add_shortcode('paktolus_form', 'paktolus_form_function');
function paktolus_form_function()
{ 
    ?>
    <style>
        .require{
            color:red;
        }
        label {
            color: #000;
            font-size: 14px;
            margin-bottom: 10px;
            font-family: sans-serif;
            letter-spacing: 0.2px;
        }
        .form-control{
            font-size: 14px;
            margin-bottom: 10px;
            font-family: sans-serif;
            letter-spacing: 0.2px;
        }
        form.pakt_forms {
    background: #eee;
    padding: 20px;
    border-radius: 5px;
}
        </style>
    <form method="post" class="pakt_forms" action="wp-content/plugins/paktolus/paktolus-pay/pay.php">
       <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="First Name">First Name <span class="require">*</span></label>
                    <input type="text" name="fname" class="form-control fname" required />
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="Last Name">Last Name <span class="require">*</span></label>
                    <input type="text" name="lname" class="form-control lname" required />
                </div>
            </div>
        </div>

       <div class="row">
                <div class="col-md-12 form-group">
                    <label for="First Name">Street Address <span class="require">*</span></label>
                    <input type="text" name="house_no_name" required class="form-control house_no_name" placeholder="House number and street name"  />
                </div>
                <div class="col-md-12 form-group">
                    <input type="text" name="appartment" class="form-control appartment" placeholder="Appartment suite, unit, etc. (optional)" />
                </div>
        </div>


       <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="City">City <span class="require">*</span></label>
                    <input type="text" required name="city" class="form-control city"  />
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="Pincode">Pincode <span class="require">*</span></label>
                    <input type="text" required name="pincode" class="form-control pincode"  />
                </div>
            </div>
        </div>


            <div class="row">
                <div class="col-md-6 form-group">
                    <label for="Email">Email address <span class="require">*</span></label>
                    <input type="email" name="email" required class="form-control email"  />
                </div>
                <div class="col-md-6 form-group">
                    <label for="phone">Phone Number <span class="require">*</span></label>
                    <input type="text" name="phone" required class="form-control phone"  />
                </div>
            </div>

            <div class="row ">
                <div class="col-md-12 form-group">
                    <label for="Amount">Amount <span class="require">*</span></label>
                    <input type="text" name="amount" required class="form-control amount"  />
                </div>
            </div>

       <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <input type="submit" name="submit" style="padding-bottom:30px;" class="form-control submit"  />
                </div>
            </div>
        </div>

    </form>
    <script>
         jQuery(".phone,.pincode,.amount").keypress(function (e) {
     //if the letter is not digit then display error and don't type anything
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        //display error message
             return false;
    }
   });
   </script>
    <?php 
}
?>
