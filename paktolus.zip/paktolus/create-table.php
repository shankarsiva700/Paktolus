<?php


function install_task_plugin()
{
    global $wpdb;

    $DBP_tb_name = $wpdb->prefix . "customerinfo"; //table name
    //create table
    $create_query = "CREATE TABLE $DBP_tb_name(id int(10) NOT NULL AUTO_INCREMENT, first_name varchar (100) DEFAULT '', last_name varchar (100) DEFAULT '', house_no_name varchar (100) DEFAULT '',appartment varchar (100) DEFAULT '',city varchar (100) DEFAULT '', pin_code varchar (100) DEFAULT '',email varchar (100) DEFAULT '',phone varchar (100) DEFAULT '',order_id varchar (100) DEFAULT '',payment_id varchar (100) DEFAULT '',amount varchar (100) DEFAULT '',paystatus varchar (100) DEFAULT '', inserteddate DATETIME, PRIMARY KEY (id))"; 
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($create_query);
    
}
// Delete table when deactivate
function my_plugin_remove_database() {
    global $wpdb; 
    $DBP_tb_name = $wpdb->prefix . "customerinfo"; 
    $sql = "DROP TABLE IF EXISTS $DBP_tb_name;";
    $wpdb->query($sql);
}    