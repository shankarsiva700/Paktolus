<?php

$keyId = 'rzp_test_oWOM812QvQXjFx';
$keySecret = 'UwvaJt1861Vs6iuiGFql1uf4';
$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);
