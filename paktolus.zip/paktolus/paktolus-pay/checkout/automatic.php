<!--  The entire list of Checkout fields is available at
 https://docs.razorpay.com/docs/checkout-form#checkout-fields -->
 <style>
   .container {
    width: 600px;
    margin: 0 auto;
    display: flex;
    justify-content: center;
    align-items: center;
    background: #eee;
    padding: 20px;
    text-align: center;
}
input.razorpay-payment-button {
    background: blue;
    color: #fff;
    padding: 10px 20px;
    cursor: pointer;
    font-size: 19px;
    border: 1px solid blue;
    border-radius: 5px;
}
input.razorpay-payment-button:hover {
    filter: drop-shadow(2px 4px 6px #ccc);
}
</style>
<div class="container">
  <div class="col-md-6" style="text-transform: uppercase;font-size: 23px;font-family: sans-serif;">
    <h1 style="text-transform: uppercase;font-size: 23px;font-family: sans-serif;">Click Pay Now button for registeration</h1>
    <h1><?php echo $_POST['fname'].' '.$_POST['lname']?></h1>
    <h2><?php echo '$ '.$_POST['amount']?></h2>
<form action="verify.php" method="POST">
  <script
    src="https://checkout.razorpay.com/v1/checkout.js"
    data-key="<?php echo $data['key']?>"
    data-amount="<?php echo $data['amount']?>"
    data-currency="INR"
    data-name="<?php echo $data['name']?>"
    data-image="<?php echo $data['image']?>"
    data-description="<?php echo $data['description']?>"
    data-prefill.name="<?php echo $data['prefill']['name']?>"
    data-prefill.email="<?php echo $data['prefill']['email']?>"
    data-prefill.contact="<?php echo $data['prefill']['contact']?>"
    data-notes.shopping_order_id="3456"
    data-order_id="<?php echo $data['order_id']?>"
    <?php if ($displayCurrency !== 'INR') { ?> data-display_amount="<?php echo $data['display_amount']?>" <?php } ?>
    <?php if ($displayCurrency !== 'INR') { ?> data-display_currency="<?php echo $data['display_currency']?>" <?php } ?>
  >
  </script>
  <!-- Any extra fields to be submitted with the form but not sent to Razorpay -->
  <input type="hidden" name="shopping_order_id" value="3456">
</form>
</div>
</div>