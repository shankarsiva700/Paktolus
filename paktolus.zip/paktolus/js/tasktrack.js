
taskTracker();
taskTrackerPopup();
TTPagination();
function modelshowhide(){

 
  jQuery('.task_tacker_model_popup button.close').click(function(){
    jQuery('.task_tacker_model_popup').fadeOut(300);
  });
  

jQuery(".task_tacker_model_popup").blur(function(){
  jQuery(this).fadeOut(300);
});

}
//Task Tracker start
/*
$(".select_squad").on("change", function(e) {
    var get_squad_val = $(this).val();
    if ($(this).val() == 2) {
      bind_tasktracker();   
    }
});
*/

(function ($) {




  $(".clear").on("click", function (e) {

   // $('.select_category').val('');  
   // $('.select_task_from').val('');  
    //$('.select_squad').val('');  
    // $("#industry_btn").html($(this).text());
    var get_squad_val = 'all';
    /*
    var get_select_category = $('.select_category').val();
    var get_select_task_from = $('.select_task_from').val();
    var get_select_todate = $('.select_todate').val();
    var get_select_fromdate = $('.select_fromdate').val(); */

    // call ajax
    $.ajax({
      url: "/wp-admin/admin-ajax.php",
      type: "POST",
      data:
        "action=trask_tracker_ajax&squad_all=" + get_squad_val ,
      success: function (results) {

        $(".task-sect").html(results);
        taskTracker();
        taskTrackerPopup();
       // TTPagination();
        $(".select_category option[value=all]").prop('selected', true);
        $(".select_task_from option[value=all]").prop('selected', true);
        $(".select_squad option[value=all]").prop('selected', true);
        $('.select_todate').val('');  
        $('.select_fromdate').val(''); 
   
   // $(".select_category option[value=all]").attr('selected', 'selected');
      }
    });
   
  });
  $(".select_squad").on("change", function (e) {
    // $("#industry_btn").html($(this).text());
    var get_squad_val = $(this).val();
    var get_select_category = $('.select_category').val();
    var get_select_task_from = $('.select_task_from').val();
    var get_select_todate = $('.select_todate').val();
    var get_select_fromdate = $('.select_fromdate').val();

    // call ajax
    $.ajax({
      url: "/wp-admin/admin-ajax.php",
      type: "POST",
      data:
        "action=trask_tracker_ajax&squad_value=" + get_squad_val + "&category_value=" + get_select_category + "&fromDate_value=" + get_select_fromdate + "&toDate_value=" + get_select_todate + "&taskfrom_value=" + get_select_task_from,
      success: function (results) {
        $(".task-sect").html(results);
        taskTracker();
        taskTrackerPopup();
       // TTPagination();
      }
    });

  });


  $(".select_category").on("change", function (e) {
    // $("#industry_btn").html($(this).text());
    var get_select_category = $(this).val();
    var get_squad_val = $('.select_squad').val();
    
    var get_select_task_from = $('.select_task_from').val();
    var get_select_todate = $('.select_todate').val();
    var get_select_fromdate = $('.select_fromdate').val();

    // call ajax
    $.ajax({
      url: "/wp-admin/admin-ajax.php",
      type: "POST",
      data:
        "action=trask_tracker_ajax&squad_value=" + get_squad_val + "&category_value=" + get_select_category + "&fromDate_value=" + get_select_fromdate + "&toDate_value=" + get_select_todate + "&taskfrom_value=" + get_select_task_from,
      success: function (results) {
        $(".task-sect").html(results);
        taskTracker();
        taskTrackerPopup();
       // TTPagination();
      }
    });

  });
  $(".select_fromdate").on("change", function (e) {
    // $("#industry_btn").html($(this).text());
    //var get_select_category = $('.select_category').val();
   // var get_squad_val = $('.select_squad').val();


    var get_squad_val =  jQuery('#squad_array_vall').val();
var get_select_category =  jQuery('#categ_array_vall').val();

    var get_select_task_from = $('.select_task_from').val();
    var get_select_todate = $('.select_todate').val();
    var get_select_fromdate = $(this).val();
    // alert(get_select_fromdate);
    // call ajax
    $.ajax({
      url: "/wp-admin/admin-ajax.php",
      type: "POST",
      data:
        "action=trask_tracker_ajax&squad_value=" + get_squad_val + "&category_value=" + get_select_category + "&fromDate_value=" + get_select_fromdate + "&toDate_value=" + get_select_todate + "&taskfrom_value=" + get_select_task_from,
      success: function (results) {
        $(".task-sect").html(results);
        taskTracker();
        taskTrackerPopup();
      //  TTPagination();
      }
    });
  });

  $(".select_todate").on("change", function (e) {
    // $("#industry_btn").html($(this).text());
  //  var get_select_category = $('.select_category').val();
//    var get_squad_val = $('.select_squad').val();

    var get_squad_val =  jQuery('#squad_array_vall').val();
var get_select_category =  jQuery('#categ_array_vall').val();

    var get_select_task_from = $('.select_task_from').val();
    var get_select_todate = $(this).val();
    var get_select_fromdate = $('.select_fromdate').val();
    // alert(get_select_fromdate);
    // call ajax
    $.ajax({
      url: "/wp-admin/admin-ajax.php",
      type: "POST",
      data:
        "action=trask_tracker_ajax&squad_value=" + get_squad_val + "&category_value=" + get_select_category + "&fromDate_value=" + get_select_fromdate + "&toDate_value=" + get_select_todate + "&taskfrom_value=" + get_select_task_from,
      success: function (results) {
        $(".task-sect").html(results);
        taskTracker();
        taskTrackerPopup();
     //   TTPagination();
      }
    });
  });
  $(".select_task_from").on("change", function (e) {
    // $("#industry_btn").html($(this).text());

   // var get_select_category = $('.select_category').val();
   // var get_squad_val = $('.select_squad').val();


    var get_squad_val =  jQuery('#squad_array_vall').val();
var get_select_category =  jQuery('#categ_array_vall').val();


    var get_select_task_from = $(this).val();
    var get_select_todate = $('.select_todate').val();
    var get_select_fromdate = $('.select_fromdate').val();
    //  alert(get_select_fromdate);
    // call ajax
    $.ajax({
      url: "/wp-admin/admin-ajax.php",
      type: "POST",
      data:
        "action=trask_tracker_ajax&squad_value=" + get_squad_val + "&category_value=" + get_select_category + "&fromDate_value=" + get_select_fromdate + "&toDate_value=" + get_select_todate + "&taskfrom_value=" + get_select_task_from,
      success: function (results) {
        $(".task-sect").html(results);
        taskTracker();
        taskTrackerPopup();
       // TTPagination();
      }
    });
  });
  /*
  function bind_tasktracker() {
    $.ajax({
      url: "/wp-admin/admin-ajax.php",
      type: "POST",
      data: "action=trask_tracker_ajax&all=all",
      success: function (results) {
        $(".task-sect").html(results);
      }
    });
  }*/

})(jQuery);

   //Task Tracker End
   //pagination start
   function TTPagination(){
    jQuery(document).ready(function($) {
  // $('#task_tracker_table').dataTable();
  $('.ttpagination').dataTable( {
   "pageLength": 10,
   
  } );
  taskTracker() ;
  taskTrackerPopup();
  //$('.ttpagination tr.odd:first-child').addClass('active');
  jQuery('#task_tracker_table tbody tr:nth-child(2)').removeClass('active');
  window.setTimeout(function(){
    $('.ttpagination tr.odd:first-child').addClass('active');
    
}, 100); //<-- Delay in milliseconds
  });
   }
   //pagination end


function taskTracker() {
  jQuery('.task_tracker tr').on('click', function () {
    jQuery('.task_tracker tr').removeClass('active');
    jQuery(this).addClass('active');
    var get_sqad_name = jQuery(this).find('td .squad').text();
    var get_cat_name = jQuery(this).find('td .category').text();
    var get_created_by = jQuery(this).find('td .createdby').text();
    var get_created_on = jQuery(this).find('td .createdon').text();
    var get_solved_by = jQuery(this).find('td .modifiedby').text();
    var get_solve_date = jQuery(this).find('td .completedon').text();
    
    jQuery('.task_tracker_bind .sqad_value').find('td:last-child').text(get_sqad_name);
    jQuery('.task_tracker_bind .cat_value').find('td:last-child').text(get_cat_name);
    jQuery('.task_tracker_bind .created_by').find('td:last-child').text(get_created_by);
    jQuery('.task_tracker_bind .solver_by').find('td:last-child').text(get_solved_by);
    jQuery('.task_tracker_bind .publish_on').find('td:last-child').text(get_created_on);
    jQuery('.task_tracker_bind .completed_on').find('td:last-child').text(get_solve_date);

  });
  jQuery('.task_tracker .active td').each(function () {
    var get_sqad_name = jQuery(this).find('.squad').text();
    var get_cat_name = jQuery(this).find('.category').text();
    var get_created_by = jQuery(this).find('.createdby').text();
    var get_created_on = jQuery(this).find('.createdon').text();
    var get_solved_by = jQuery(this).find('.modifiedby').text();
    var get_solve_date = jQuery(this).find('.completedon').text();

    jQuery('.task_tracker_bind .sqad_value').find('td:last-child').text(get_sqad_name);
    jQuery('.task_tracker_bind .cat_value').find('td:last-child').text(get_cat_name);
    jQuery('.task_tracker_bind .created_by').find('td:last-child').text(get_created_by);
    jQuery('.task_tracker_bind .solver_by').find('td:last-child').text(get_solved_by);
    jQuery('.task_tracker_bind .publish_on').find('td:last-child').text(get_created_on);
    jQuery('.task_tracker_bind .completed_on').find('td:last-child').text(get_solve_date);
  });
 
}

function taskTrackerPopup(){
jQuery('.task_tracker_popup').on('click', function(e) {
  jQuery('.task_tacker_model_popup').fadeIn(300,function(){jQuery(this).focus();});
  e.preventDefault();
      var get_sqad_name = jQuery(this).parent().find('.squad').text();
      var get_cat_name = jQuery(this).parent().find('.category').text();
      var get_created_by = jQuery(this).parent().find('.createdby').text();
      var get_created_on = jQuery(this).parent().find('.createdon').text();
      var modifiedby = jQuery(this).parent().find('.modifiedby').text();
      var get_completedon= jQuery(this).parent().find('.completedon').text();
      var get_description= jQuery(this).parent().find('.description').text();
      var get_id_title= jQuery(this).parent().find('.title').text();
  //alert(get_sqad_name);
  jQuery('.append_sqaud').text(get_sqad_name);
  jQuery('.append_category').text(get_cat_name);
  jQuery('.append_created').text(get_created_by);
  jQuery('.append_modified').text(modifiedby);
  jQuery('.append_created_on').text(get_created_on);
  jQuery('.append_completed').text(get_completedon);
  jQuery('.append_description').text(get_description);
  jQuery('.modal-title').text(get_id_title);
  modelshowhide();
  });
}


  

jQuery(document).ready(function(){

  /*********************convert select into multiselect************************/
 
        
  /**********************creating of checkboxes for each select option************************/
  jQuery(document).on("click", ".MultiCheckBox", function () {
                  var detail = jQuery(this).next();
                  detail.show();
              });
  
              jQuery(document).on("click", ".MultiCheckBoxDetailHeader input", function (e) {
                  e.stopPropagation();
                  var hc = jQuery(this).prop("checked");
                  jQuery(this).closest(".MultiCheckBoxDetail").find(".MultiCheckBoxDetailBody input").prop("checked", hc);
                  jQuery(this).closest(".MultiCheckBoxDetail").next();//.UpdateSelect();
              });
  
              jQuery(document).on("click", ".MultiCheckBoxDetailHeader", function (e) {
                  var inp = jQuery(this).find("input");
                  var chk = inp.prop("checked");
                  inp.prop("checked", !chk);
                  jQuery(this).closest(".MultiCheckBoxDetail").find(".MultiCheckBoxDetailBody input").prop("checked", !chk);
                  jQuery(this).closest(".MultiCheckBoxDetail").next();//.UpdateSelect();
              });
  
              jQuery(document).on("click", ".MultiCheckBoxDetail .cont input", function (e) {
                  e.stopPropagation();
                  jQuery(this).closest(".MultiCheckBoxDetail").next();//.UpdateSelect();
  
                  var val = (jQuery(".MultiCheckBoxDetailBody input:checked").length == jQuery(".MultiCheckBoxDetailBody input").length)
                  jQuery(".MultiCheckBoxDetailHeader input").prop("checked", val);
              });
  
              jQuery(document).on("click", ".MultiCheckBoxDetail .cont", function (e) {
                  var inp = jQuery(this).find("input");
                  var chk = inp.prop("checked");
                  inp.prop("checked", !chk);
  
                  var multiCheckBoxDetail = jQuery(this).closest(".MultiCheckBoxDetail");
                  var multiCheckBoxDetailBody = jQuery(this).closest(".MultiCheckBoxDetailBody");
                  multiCheckBoxDetail.next();//.UpdateSelect();
  
                  var val = (jQuery(".MultiCheckBoxDetailBody input:checked").length == jQuery(".MultiCheckBoxDetailBody input").length)
                  jQuery(".MultiCheckBoxDetailHeader input").prop("checked", val);
                
             });
  
              jQuery(document).mouseup(function (e) {
                  var container = jQuery(".MultiCheckBoxDetail");
                  if (!container.is(e.target) && container.has(e.target).length === 0) {
                      container.hide();
                  }
              });
});
  
          var defaultMultiCheckBoxOption = { width: '220px', defaultText: 'Select Below', height: '200px' };
  
          jQuery.fn.extend({
              CreateMultiCheckBox: function (options) {
  
                  var localOption = {};
                  localOption.width = (options != null && options.width != null && options.width != undefined) ? options.width : defaultMultiCheckBoxOption.width;
                  localOption.defaultText = (options != null && options.defaultText != null && options.defaultText != undefined) ? options.defaultText : defaultMultiCheckBoxOption.defaultText;
                  localOption.height = (options != null && options.height != null && options.height != undefined) ? options.height : defaultMultiCheckBoxOption.height;
  
                  this.hide();
                  this.attr("multiple", "multiple");
                  var divSel = jQuery("<div class='MultiCheckBox'>" + localOption.defaultText + "<span class='k-icon k-i-arrow-60-down'><svg aria-hidden='true' focusable='false' data-prefix='fas' data-icon='sort-down' role='img' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 320 512' class='svg-inline--fa fa-sort-down fa-w-10 fa-2x'><path fill='currentColor' d='M41 288h238c21.4 0 32.1 25.9 17 41L177 448c-9.4 9.4-24.6 9.4-33.9 0L24 329c-15.1-15.1-4.4-41 17-41z' class=''></path></svg></span></div>").insertBefore(this);
                  divSel.css({ "width": localOption.width });
  
                  var detail = jQuery("<div class='MultiCheckBoxDetail'><div class='MultiCheckBoxDetailHeader'><input type='checkbox' class='mulinput' value='-1982' /><div>Select All</div></div><div class='MultiCheckBoxDetailBody'></div></div>").insertAfter(divSel);
                  detail.css({ "width": parseInt(options.width) + 10, "max-height": localOption.height });
                  var multiCheckBoxDetailBody = detail.find(".MultiCheckBoxDetailBody");
  
                  this.find("option").each(function () {
                      var val = jQuery(this).attr("value");
  
                      if (val == undefined)
                          val = '';
  
                      multiCheckBoxDetailBody.append("<div class='cont'><div><input type='checkbox' class='mulinput' value='" + val + "' /></div><div>" + jQuery(this).text() + "</div></div>");
                  });
  
                  multiCheckBoxDetailBody.css("max-height", (parseInt(jQuery(".MultiCheckBoxDetail").css("max-height")) - 28) + "px");
              },
              UpdateSelect: function () {
                  var arr = [];
  
                  this.prev().find(".mulinput:checked").each(function () {
                      arr.push(jQuery(this).val());
                  });
  
                  this.val(arr);
                  alert(arr);
              },
  
  });


        
  jQuery("#squad_select_dropdow").CreateMultiCheckBox({ width: '100%', defaultText : 'Select Sqaud', height:'auto' }); 
  

var array_out = [];
              jQuery(".select_squad_filter .mulinput").on('change',function(){
                var array = [];
                jQuery(".select_squad_filter .mulinput").each(function(){
                   if(jQuery(this).is(":checked"))
                   {
                    var get_vals = '"'+jQuery(this).val()+'"';
                   // alert(get_vals);
                 
                    array.push(get_vals);
                    
                   
                }    
                }); 
                jQuery('#squad_array_vall').val(array);

               
             
                var get_squad_val =  jQuery('#squad_array_vall').val();
var get_select_category =  jQuery('#categ_array_vall').val();
    var get_select_task_from = $('.select_task_from').val();
    var get_select_todate = $('.select_todate').val();
    var get_select_fromdate = $('.select_fromdate').val();

    // call ajax
    $.ajax({
      url: "/wp-admin/admin-ajax.php",
      type: "POST",
      data:
        "action=trask_tracker_ajax&squad_value=" + get_squad_val + "&category_value=" + get_select_category + "&fromDate_value=" + get_select_fromdate + "&toDate_value=" + get_select_todate + "&taskfrom_value=" + get_select_task_from,
      success: function (results) {
        $(".task-sect").html(results);
        taskTracker();
        taskTrackerPopup();
       // TTPagination();
      }
    });



              });


              

        
  jQuery("#category_select_dropdow").CreateMultiCheckBox({ width: '100%', defaultText : 'Select Sqaud', height:'auto' }); 
  


  jQuery(".select_category_filter .mulinput").on('change',function(){
   

   var array = [];
   jQuery(".select_category_filter .mulinput").each(function(){
      if(jQuery(this).is(":checked"))
      {
       var get_vals = '"'+jQuery(this).val()+'"';
      // alert(get_vals);
       array.push(get_vals);
   }    
   }); 
   jQuery('#categ_array_vall').val(array);
   
 
    var get_squad_val =  jQuery('#squad_array_vall').val();
var get_select_category =  jQuery('#categ_array_vall').val();
var get_select_task_from = $('.select_task_from').val();
var get_select_todate = $('.select_todate').val();
var get_select_fromdate = $('.select_fromdate').val();

// call ajax
$.ajax({
url: "/wp-admin/admin-ajax.php",
type: "POST",
data:
"action=trask_tracker_ajax&squad_value=" + get_squad_val + "&category_value=" + get_select_category + "&fromDate_value=" + get_select_fromdate + "&toDate_value=" + get_select_todate + "&taskfrom_value=" + get_select_task_from,
success: function (results) {
$(".task-sect").html(results);
taskTracker();
taskTrackerPopup();
// TTPagination();
}
});

  });
          
             